#!/bin/bash
#
# crystal_common.sh settings file by locupleto
# https://github.com/locupleto/crystal-widgets
#
# This file contains some common settings for the widgets

# Working directory for htop-related widgets, (defaults to /tmp if not set)
export HTOP_TEMP_DIR=$HOME/tmp

# crystal-calendar Start day of the week (defaults to SUNDAY if not set)
export START_DAY_OF_WEEK="MONDAY"

# crystal-htop-cpu-bar: one bar per logical CPU ("logical", the default) or
# one per physical core with hyperthread siblings averaged ("physical").
# Only matters on Intel Macs with Hyper-Threading; Apple silicon has no SMT.
export CPU_BARS="logical"

# ------ Example bar color schemes to play with -----------------------------

# Default bar color is semi-transparent gold with white outline
#export BAR_COLOR=${BAR_COLOR:-'rgba(255, 204, 0, 0.5)'} 
#export BAR_BORDER_COLOR=${BAR_BORDER_COLOR:-'rgba(255, 255, 255, 0.3)'}  

# Dodger Blue with 50% transparency
export BAR_COLOR='rgba(30, 144, 255, 1.0)'  
export BAR_BORDER_COLOR='rgba(30, 144, 255, 1.0)' 

# External theme hook: an optional theme file may override the bar color
# via CRYSTAL_BAR_COLOR; when it is absent the default above is kept.
if [ -f "$HOME/.config/gallery/state/theme.sh" ]; then
  . "$HOME/.config/gallery/state/theme.sh"
  export BAR_COLOR="${CRYSTAL_BAR_COLOR:-$BAR_COLOR}"
  export BAR_BORDER_COLOR="${CRYSTAL_BAR_COLOR:-$BAR_BORDER_COLOR}"
fi

# Medium Sea Green with full opacity
#export BAR_COLOR='rgba(60, 179, 113, 1.0)'  
#export BAR_BORDER_COLOR='rgba(60, 179, 113, 0.3)' 

# Spring Green with full opacity
#export BAR_COLOR='rgba(0, 255, 127, 1.0)'  
#export BAR_BORDER_COLOR='rgba(0, 255, 127, 0.3)'  

# ------ Paths to installation specific command-line tools ------------------

export FASTFETCH_CMD=/opt/homebrew/bin/fastfetch

# ------ crystal-weather settings -------------------------------------------

# OpenWeatherMap API key (free at https://home.openweathermap.org/api_keys).
# Leave empty to disable the weather panel entirely (it stays invisible).
export OPENWEATHERMAP_API_KEY=""

# Location as "City,ISO-country-code"
export WEATHER_LOCATION="Stockholm,SE"

# Units: metric (Celsius, m/s) or imperial (Fahrenheit, mph)
export WEATHER_UNITS="metric"

# Icon set: meteocons-line (default) | meteocons-fill | weather-icons
export WEATHER_ICON_SET="meteocons-line"
