# crystal-weather.widget by locupleto
#
# https://github.com/locupleto/crystal-widgets-v2
#
# Current weather conditions from OpenWeatherMap. The panel is entirely
# invisible unless OPENWEATHERMAP_API_KEY is configured in
# crystal_common.sh and at least one fetch has succeeded (fail-safe).

command: "crystal-weather.widget/widget_runner.sh"

# Frequency of data refresh. The runner only calls the OpenWeatherMap
# API every 10 minutes; in between it re-reads the local cache, so this
# can be much faster than the API interval.
refreshFrequency: 60000

# Styling for the widget. NOTE: the outer widget style carries position
# only -- all visible chrome sits on .container so the entire panel can
# disappear when no API key / no data is available (fail-safe).
style: """
  top: 229px
  left: 10px
  width: 390px
  overflow: hidden
  color: var(--crystal-static, #fff)
  font-family: Helvetica Neue

  .container
    display: none
    width: 370px
    padding: 10px
    background: rgba(#FFF, .1)
    border-radius: 5px

  .content
    display: flex
    align-items: center
    gap: 12px
    height: 60px

  .weather-icon
    flex: 0 0 60px
    width: 60px
    height: 60px

  .weather-icon svg
    display: block
    width: 100%
    height: 100%

  // meteocons-line bakes its colours in as stroke attributes. When an
  // external theme feed is present only the greys (cloud, moon and fog
  // outlines) follow the static colour; sun, rain and snow keep their own.
  .weather-icon svg [stroke="#e5e7eb"]
    stroke: var(--crystal-static-90, #e5e7eb)

  .weather-icon svg [stroke="#d1d5db"]
    stroke: var(--crystal-static-85, #d1d5db)

  .weather-icon svg [stroke="#9ca3af"]
    stroke: var(--crystal-static-65, #9ca3af)

  .weather-icon.tinted svg,
  .weather-icon.tinted svg path
    fill: var(--crystal-static-92, rgba(255,255,255,.92))

  .temp
    font-size: 30px
    font-weight: 200
    line-height: 32px
    text-shadow: 0 1px 0px rgba(#000, .7)

  .condition
    font-size: 11px
    font-weight: 300
    color: var(--crystal-static-90, rgba(255,255,255,.9))

  .secondary
    margin-left: auto
    text-align: right
    font-size: 11px
    font-weight: 300
    line-height: 15px
    color: var(--crystal-static-75, rgba(255,255,255,.75))

  .city
    font-size: 10px
    text-transform: uppercase
    font-weight: bold
    color: var(--crystal-static, #fff)

  .stale-hint
    font-size: 9px
    font-weight: 300
    color: var(--crystal-static-45, rgba(255,255,255,.45))
    margin-right: 4px
"""

# Rendering the widget layout (static skeleton; update() fills it in)
render: ->
  """
  <div class="container">
    <div class="content">
      <div class="weather-icon"></div>
      <div class="primary">
        <div class="temp"></div>
        <div class="condition"></div>
      </div>
      <div class="secondary">
        <div><span class="stale-hint"></span><span class="city"></span></div>
        <div class="feels"></div>
        <div class="extras"></div>
      </div>
    </div>
  </div>
  """

# Updating the widget with new data
update: (output, domEl) ->
  container = $(domEl).find('.container')

  # FAIL-SAFE: empty output means no key / no cache -> hide everything
  if not output? or output.trim() == ""
    container.hide()
    return

  try
    data = JSON.parse(output)
  catch error
    container.hide()
    return

  if data.status != "ok"
    container.hide()
    return

  # Inject the SVG inline so SMIL animations run and the Erik Flowers
  # glyphs can be tinted via CSS. Only one icon is in the DOM at a time,
  # so gradient ids inside meteocons files cannot collide.
  iconEl = $(domEl).find('.weather-icon')
  iconEl.html(data.icon_svg)
  iconEl.toggleClass('tinted', data.icon_set == 'weather-icons')

  $(domEl).find('.temp').text(data.temp)
  $(domEl).find('.condition').text(data.condition)
  $(domEl).find('.city').text(data.city)
  $(domEl).find('.feels').text("Feels like #{data.feels}")
  $(domEl).find('.extras').text("#{data.humidity} · #{data.wind}")
  $(domEl).find('.stale-hint').text(if data.stale then "⟳ #{data.age_min}m" else "")

  container.css('display', 'block')
